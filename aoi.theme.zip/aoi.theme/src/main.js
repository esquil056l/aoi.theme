export default {
  name: "Aoi.js Syntax Highlighter",
  init: function () {
    console.log("Aoi.js Syntax Highlighter ativado!");

    const aoiJsHighlightingRules = [
      {
        regex: /\$get\w*\((.*?)\)/g,
        css: "color: #FFAA00; font-weight: bold;"
      },
      {
        regex: /\$let\w*\((.*?)\)/g,
        css: "color: #00FF00; font-style: italic;"
      },
      {
        regex: /\$[a-zA-Z]+\((.*?)\)/g,
        css: "color: #007BFF; font-weight: bold;"
      },
      {
        regex: /\$(set|send|edit|delete|create|update)\w*\((.*?)\)/g,
        css: "color: #FF6347; font-style: italic;"
      },
      {
        regex: /\/\*[\s\S]*?\*\/|\/\/.*/g,
        css: "color: #888888; font-style: italic;"
      },
      {
        regex: /("|').*?("|')/g,
        css: "color: #FF00FF;"
      },
      {
        regex: /\bfunction\b|\bconst\b|\blet\b|\breturn\b/g,
        css: "color: #00FFFF; font-weight: bold;"
      },
      {
        regex: /\b\d+\b/g,
        css: "color: #FF4500;"
      },
      {
        regex: /\/\*\s*ERROR\s*\*\//g,
        css: "color: #FF0000; font-weight: bold; background-color: #FFDDDD;"
      },
      {
        regex: /\/\*\s*WARNING\s*\*\//g,
        css: "color: #FFA500; font-weight: bold; background-color: #FFF3E0;"
      },
      {
        regex: /\/\*\s*INFO\s*\*\//g,
        css: "color: #008000; font-weight: bold; background-color: #E8F5E9;"
      }
    ];

    editorManager.addCustomHighlighter("aoi-js-highlighter", aoiJsHighlightingRules);
    
    editorManager.addNotification({
      title: "Aoi.js Syntax Highlighter",
      text: "Tema e realce de código para Aoi.js ativados.",
      type: "success",
      timeout: 5000
    });

    console.log("%cAoi.js Syntax Highlighter ativado!", "color: #007BFF; font-weight: bold;");
  },

  destroy: function () {
    console.log("Aoi.js Syntax Highlighter desativado.");
    editorManager.removeCustomHighlighter("aoi-js-highlighter");
  }
};
